# RD Educhub 2.0

Launch-ready static academic website.

## Included
- DU Physics syllabus links
- Original DU-aligned EMT and Mechanics notes
- Original EMT and Mechanics lecture PPTs
- 100 original EMT practice questions
- 100 original Mechanics practice questions
- Interactive 10-question random online test
- GATE official download link
- CSIR-NET official portal link
- Copyright-safe approach for previous-year papers: link to official sources rather than re-hosting copyrighted papers.

## Launch
Upload the entire folder to GitHub Pages, Netlify, Vercel, or another static host. Keep the folder structure unchanged.

## Important
The website is independent and not affiliated with DU, GATE or NTA. Verify current official syllabi, notices, question papers and answer keys from the relevant official portals.
