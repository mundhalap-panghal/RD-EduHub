RD EduHub — Free Academic Website

Contents:
- DU Physics: Mechanics + Electromagnetic Theory
- Notes PDFs
- Lecture PPTs
- EMT and Mechanics practice banks
- Random online test
- Official DU syllabus links
- Official GATE syllabus, downloads and pattern links
- Official CSIR-NET portal link

How to publish for free:
1. Upload this entire folder to a GitHub repository.
2. In GitHub: Settings → Pages → Deploy from branch → main/root.
3. GitHub will provide a free public URL.
Alternative: upload the folder to Netlify Drop for a free static site.

Copyright:
RD EduHub should host original material or material for which you have permission. Copyrighted DU/GATE/NET papers are linked to official sources instead of being copied here.
